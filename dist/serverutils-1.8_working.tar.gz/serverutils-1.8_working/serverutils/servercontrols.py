class Controls:
    def __init__(self,server):
        self.server=server
        self.inittasks()
    def inittasks(self):
        pass
    def on_post(self,data):
        pass
    def on_get(self,data):
        pass
