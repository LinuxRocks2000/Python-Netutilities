A simple library for writing TCP/Websocket servers in Python

Currently about as unstable as it is possible to be in a PyPi project
